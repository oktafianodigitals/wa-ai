import Database from 'better-sqlite3';
import { config } from './config.js';

let db;

export function initDB() {
  db = new Database(config.DB_FILE);
  db.pragma('journal_mode = WAL');

  db.exec(`
    CREATE TABLE IF NOT EXISTS messages (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      chat_jid TEXT NOT NULL,
      sender TEXT NOT NULL,
      content TEXT NOT NULL,
      is_from_bot INTEGER DEFAULT 0,
      timestamp INTEGER NOT NULL
    );
    CREATE INDEX IF NOT EXISTS idx_messages_chat ON messages(chat_jid, timestamp);
    CREATE TABLE IF NOT EXISTS contacts (
      jid TEXT PRIMARY KEY,
      name TEXT,
      phone TEXT,
      pic_checked INTEGER DEFAULT 0,
      pic_ok INTEGER DEFAULT 0,
      pic_version INTEGER DEFAULT 0,
      updated INTEGER DEFAULT 0
    );
    CREATE TABLE IF NOT EXISTS categories (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL UNIQUE COLLATE NOCASE,
      description TEXT DEFAULT '',
      color TEXT DEFAULT '#2f6f9f',
      created INTEGER NOT NULL
    );
    CREATE TABLE IF NOT EXISTS chat_categories (
      chat_jid TEXT PRIMARY KEY,
      category_id INTEGER NOT NULL,
      assigned_by TEXT NOT NULL DEFAULT 'ai',
      confidence REAL,
      reason TEXT DEFAULT '',
      updated INTEGER NOT NULL
    );
    CREATE INDEX IF NOT EXISTS idx_chat_categories_cat ON chat_categories(category_id);
  `);

  // Migrasi ringan: kolom lampiran pada tabel messages (DB lama tetap kompatibel).
  const cols = new Set(db.prepare('PRAGMA table_info(messages)').all().map(c => c.name));
  const addCols = {
    media_type: 'TEXT',   // image | video | audio | document | sticker | contact | location | other
    media_name: 'TEXT',
    media_mime: 'TEXT',
    media_size: 'INTEGER',
    media_path: 'TEXT',   // nama file di folder uploads/ (kosong bila tidak diunduh)
    media_text: 'TEXT',   // isi teks hasil ekstraksi (file teks) untuk konteks AI
  };
  for (const [name, type] of Object.entries(addCols)) {
    if (!cols.has(name)) db.exec(`ALTER TABLE messages ADD COLUMN ${name} ${type}`);
  }

  console.log(`[DB] SQLite connected: ${config.DB_FILE}`);
  return db;
}

export function getDB() {
  if (!db) throw new Error('Database not initialized');
  return db;
}

/** Simpan pesan. `media` opsional: { type, name, mime, size, path, text }. Mengembalikan id baris. */
export function saveMessage(chatJid, sender, content, isFromBot = false, media = null) {
  const stmt = getDB().prepare(
    `INSERT INTO messages
       (chat_jid, sender, content, is_from_bot, timestamp,
        media_type, media_name, media_mime, media_size, media_path, media_text)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
  );
  const r = stmt.run(
    chatJid, sender, content, isFromBot ? 1 : 0, Date.now(),
    media?.type ?? null, media?.name ?? null, media?.mime ?? null,
    media?.size ?? null, media?.path ?? null, media?.text ?? null,
  );
  return Number(r.lastInsertRowid);
}

export function getMessage(id) {
  return getDB().prepare('SELECT * FROM messages WHERE id = ?').get(id) || null;
}

export function getHistory(chatJid, maxHistory = 70) {
  const stmt = getDB().prepare(
    `SELECT id, sender, content, is_from_bot, timestamp,
            media_type, media_name, media_mime, media_size, media_path, media_text
     FROM messages
     WHERE chat_jid = ?
     ORDER BY timestamp DESC
     LIMIT ?`
  );
  const rows = stmt.all(chatJid, maxHistory);
  return rows.reverse();
}

const MAX_FILE_TEXT_FOR_AI = 3000;

export function formatHistoryForAI(history) {
  return history.map(msg => {
    let content = msg.content;
    if (!msg.is_from_bot && msg.media_text) {
      content += `\n[Isi file "${msg.media_name || 'lampiran'}"]\n${String(msg.media_text).slice(0, MAX_FILE_TEXT_FOR_AI)}`;
    }
    return { role: msg.is_from_bot ? 'assistant' : 'user', content };
  });
}

export function listChats() {
  const stmt = getDB().prepare(`
    SELECT m.chat_jid,
           COUNT(*) as total_messages,
           MAX(m.timestamp) as last_time,
           (
             SELECT content FROM messages m2
             WHERE m2.chat_jid = m.chat_jid
             ORDER BY m2.timestamp DESC, m2.id DESC LIMIT 1
           ) as last_message,
           c.name as contact_name, c.phone as contact_phone,
           c.pic_ok as pic_ok, c.pic_version as pic_version,
           cc.category_id as category_id, cc.assigned_by as category_by,
           cat.name as category_name, cat.color as category_color
    FROM messages m
    LEFT JOIN contacts c ON c.jid = m.chat_jid
    LEFT JOIN chat_categories cc ON cc.chat_jid = m.chat_jid
    LEFT JOIN categories cat ON cat.id = cc.category_id
    GROUP BY m.chat_jid
    ORDER BY last_time DESC
  `);
  return stmt.all();
}

/* ---------- Kontak (nama, nomor, foto profil) ---------- */

export function getContact(jid) {
  return getDB().prepare('SELECT * FROM contacts WHERE jid = ?').get(jid) || null;
}

export function upsertContact(jid, { name, phone } = {}) {
  if (!jid) return;
  const db = getDB();
  const cur = getContact(jid);
  const cleanName = typeof name === 'string' ? name.trim().slice(0, 120) : '';
  const cleanPhone = typeof phone === 'string' ? phone.replace(/\D/g, '').slice(0, 20) : '';
  if (!cur) {
    db.prepare('INSERT INTO contacts (jid, name, phone, updated) VALUES (?, ?, ?, ?)')
      .run(jid, cleanName || null, cleanPhone || null, Date.now());
    return;
  }
  const nextName = cleanName || cur.name;
  const nextPhone = cleanPhone || cur.phone;
  if (nextName !== cur.name || nextPhone !== cur.phone) {
    db.prepare('UPDATE contacts SET name = ?, phone = ?, updated = ? WHERE jid = ?')
      .run(nextName, nextPhone, Date.now(), jid);
  }
}

export function setContactPicture(jid, ok, version = Date.now()) {
  upsertContact(jid);
  getDB().prepare('UPDATE contacts SET pic_checked = ?, pic_ok = ?, pic_version = ? WHERE jid = ?')
    .run(Date.now(), ok ? 1 : 0, ok ? version : (getContact(jid)?.pic_version || 0), jid);
}

export function listChatJids() {
  return getDB().prepare('SELECT DISTINCT chat_jid FROM messages').all().map(r => r.chat_jid);
}
/** Daftar file lampiran sebuah chat (untuk dihapus dari disk saat chat dibersihkan). */
export function listChatMediaPaths(chatJid) {
  return getDB().prepare('SELECT media_path FROM messages WHERE chat_jid = ? AND media_path IS NOT NULL')
    .all(chatJid).map(r => r.media_path);
}

export function clearChat(chatJid) {
  // Kategori yang ditetapkan AI ikut direset; kategori manual dipertahankan.
  getDB().prepare("DELETE FROM chat_categories WHERE chat_jid = ? AND assigned_by != 'manual'").run(chatJid);
  return getDB().prepare('DELETE FROM messages WHERE chat_jid = ?').run(chatJid).changes;
}

export function clearMessages() {
  getDB().prepare('DELETE FROM chat_categories').run();
  getDB().prepare('DELETE FROM contacts').run();
  getDB().prepare('DELETE FROM messages').run();
  getDB().prepare('DELETE FROM sqlite_sequence WHERE name = ?').run('messages');
}


export function getStats() {
  const db = getDB();
  const startOfDay = new Date();
  startOfDay.setHours(0, 0, 0, 0);
  const one = (sql, ...p) => db.prepare(sql).get(...p).c;
  return {
    totalMessages: one('SELECT COUNT(*) c FROM messages'),
    totalChats: one('SELECT COUNT(DISTINCT chat_jid) c FROM messages'),
    botReplies: one('SELECT COUNT(*) c FROM messages WHERE is_from_bot = 1'),
    incoming: one('SELECT COUNT(*) c FROM messages WHERE is_from_bot = 0'),
    today: one('SELECT COUNT(*) c FROM messages WHERE timestamp >= ?', startOfDay.getTime()),
    // 7 hari terakhir (untuk grafik)
    daily: Array.from({ length: 7 }, (_, i) => {
      const from = new Date(startOfDay); from.setDate(from.getDate() - (6 - i));
      const to = new Date(from); to.setDate(to.getDate() + 1);
      return {
        date: from.getTime(),
        incoming: one('SELECT COUNT(*) c FROM messages WHERE is_from_bot = 0 AND timestamp >= ? AND timestamp < ?', from.getTime(), to.getTime()),
        bot: one('SELECT COUNT(*) c FROM messages WHERE is_from_bot = 1 AND timestamp >= ? AND timestamp < ?', from.getTime(), to.getTime()),
      };
    }),
  };
}

export function getRecentMessages(limit = 8) {
  return getDB().prepare(
    `SELECT m.id, m.chat_jid, m.sender, m.content, m.is_from_bot, m.timestamp, m.media_type,
            c.name as contact_name, c.phone as contact_phone, c.pic_ok as pic_ok, c.pic_version as pic_version
     FROM messages m LEFT JOIN contacts c ON c.jid = m.chat_jid
     ORDER BY m.timestamp DESC, m.id DESC LIMIT ?`
  ).all(limit);
}


/* ---------- Kategori customer ---------- */

export function listCategories() {
  return getDB().prepare(`
    SELECT c.id, c.name, c.description, c.color, c.created,
           (SELECT COUNT(*) FROM chat_categories cc WHERE cc.category_id = c.id) AS total
    FROM categories c ORDER BY c.name COLLATE NOCASE
  `).all();
}

export function getCategory(id) {
  return getDB().prepare('SELECT * FROM categories WHERE id = ?').get(id) || null;
}

export function createCategory({ name, description = '', color = '#2f6f9f' }) {
  const r = getDB().prepare('INSERT INTO categories (name, description, color, created) VALUES (?, ?, ?, ?)')
    .run(name, description, color, Date.now());
  return Number(r.lastInsertRowid);
}

export function updateCategory(id, { name, description, color }) {
  const cur = getCategory(id);
  if (!cur) return false;
  getDB().prepare('UPDATE categories SET name = ?, description = ?, color = ? WHERE id = ?')
    .run(name ?? cur.name, description ?? cur.description, color ?? cur.color, id);
  return true;
}

export function deleteCategory(id) {
  getDB().prepare('DELETE FROM chat_categories WHERE category_id = ?').run(id);
  return getDB().prepare('DELETE FROM categories WHERE id = ?').run(id).changes > 0;
}

export function getChatCategory(chatJid) {
  return getDB().prepare(`
    SELECT cc.chat_jid, cc.category_id, cc.assigned_by, cc.confidence, cc.reason, cc.updated,
           cat.name AS category_name, cat.color AS category_color
    FROM chat_categories cc JOIN categories cat ON cat.id = cc.category_id
    WHERE cc.chat_jid = ?`).get(chatJid) || null;
}

export function setChatCategory(chatJid, categoryId, { by = 'ai', confidence = null, reason = '' } = {}) {
  getDB().prepare(`
    INSERT INTO chat_categories (chat_jid, category_id, assigned_by, confidence, reason, updated)
    VALUES (?, ?, ?, ?, ?, ?)
    ON CONFLICT(chat_jid) DO UPDATE SET
      category_id = excluded.category_id, assigned_by = excluded.assigned_by,
      confidence = excluded.confidence, reason = excluded.reason, updated = excluded.updated
  `).run(chatJid, categoryId, by, confidence, String(reason || '').slice(0, 300), Date.now());
}

export function clearChatCategory(chatJid) {
  return getDB().prepare('DELETE FROM chat_categories WHERE chat_jid = ?').run(chatJid).changes > 0;
}
